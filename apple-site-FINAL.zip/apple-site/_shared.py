# Shared CSS and nav components for Apple-theme site

SHARED_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Figtree:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

:root {
  --white: #ffffff;
  --bg: #fbfbfd;
  --light: #f5f5f7;
  --mid-light: #e8e8ed;
  --border: #d2d2d7;
  --mid: #6e6e73;
  --dark: #1d1d1f;
  --blue: #0071e3;
  --blue-h: #0077ed;
  --blue-light: #e8f0fe;
  --green: #30d158;
  --red: #ff453a;
  --amber: #ffd60a;
  --r: 18px;
  --r-sm: 12px;
  --nh: 52px;
  --shadow: 0 2px 20px rgba(0,0,0,.06), 0 0 0 1px rgba(0,0,0,.03);
  --shadow-lg: 0 8px 40px rgba(0,0,0,.12), 0 0 0 1px rgba(0,0,0,.04);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
body { background: var(--bg); color: var(--dark); font-family: 'Figtree', -apple-system, sans-serif; font-size: 17px; line-height: 1.6; overflow-x: hidden; }
a { color: inherit; text-decoration: none; }
img { max-width: 100%; display: block; }

/* ── NAV ── */
nav {
  position: sticky; top: 0; z-index: 200;
  height: var(--nh);
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 22px;
  background: rgba(251,251,253,.85);
  backdrop-filter: saturate(180%) blur(20px);
  -webkit-backdrop-filter: saturate(180%) blur(20px);
  border-bottom: 1px solid rgba(0,0,0,.08);
}
.nav-logo {
  font-family: 'Syne', sans-serif;
  font-size: 18px; font-weight: 800;
  color: var(--dark); letter-spacing: -.02em;
}
.nav-logo span { color: var(--blue); }
.nav-desktop { display: none; gap: 0; list-style: none; align-items: center; }
.nav-desktop a {
  font-size: 13px; font-weight: 500;
  color: var(--mid);
  padding: 6px 14px;
  border-radius: 100px;
  transition: color .15s, background .15s;
  white-space: nowrap;
}
.nav-desktop a:hover { color: var(--dark); background: rgba(0,0,0,.04); }
.nav-desktop a.act { color: var(--dark); font-weight: 600; }
.nav-cta-btn {
  display: none;
  background: var(--blue);
  color: #fff;
  font-size: 13px; font-weight: 600;
  padding: 7px 16px;
  border-radius: 100px;
  transition: background .15s, transform .1s;
  white-space: nowrap;
}
.nav-cta-btn:hover { background: var(--blue-h); transform: scale(1.02); }
.hamburger {
  background: none; border: none; cursor: pointer;
  width: 36px; height: 36px;
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 5px;
  border-radius: 50%;
  transition: background .15s;
}
.hamburger:hover { background: rgba(0,0,0,.06); }
.hamburger span { display: block; width: 18px; height: 1.5px; background: var(--dark); border-radius: 2px; transition: transform .25s, opacity .2s; }
.hamburger.open span:nth-child(1) { transform: translateY(6.5px) rotate(45deg); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: translateY(-6.5px) rotate(-45deg); }
.mmenu {
  position: fixed; top: var(--nh); left: 0; right: 0; bottom: 0; z-index: 190;
  background: rgba(251,251,253,.96);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  padding: 24px 22px;
  display: flex; flex-direction: column; gap: 2px;
  transform: translateY(-8px); opacity: 0; pointer-events: none;
  transition: transform .25s, opacity .25s;
}
.mmenu.open { transform: none; opacity: 1; pointer-events: all; }
.mmenu a {
  font-size: 17px; font-weight: 500; color: var(--dark);
  padding: 14px 16px;
  border-radius: var(--r-sm);
  transition: background .15s;
  display: block;
}
.mmenu a:hover, .mmenu a.act { background: var(--light); }
.mmenu .m-cta {
  margin-top: 12px;
  background: var(--blue); color: #fff;
  text-align: center; font-weight: 600;
  border-radius: var(--r);
  padding: 16px;
}
.mmenu .m-cta:hover { background: var(--blue-h); }

/* ── REVEAL ── */
.reveal { opacity: 0; transform: translateY(20px); transition: opacity .7s ease, transform .7s ease; }
.reveal.vis { opacity: 1; transform: none; }
.reveal.d1 { transition-delay: .1s; }
.reveal.d2 { transition-delay: .2s; }
.reveal.d3 { transition-delay: .3s; }

/* ── FOOTER ── */
footer {
  background: var(--light);
  border-top: 1px solid var(--border);
  padding: 40px 22px;
}
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-logo { font-family: 'Syne', sans-serif; font-size: 20px; font-weight: 800; color: var(--dark); letter-spacing: -.02em; margin-bottom: 6px; }
.footer-logo span { color: var(--blue); }
.footer-sub { font-size: 13px; color: var(--mid); margin-bottom: 20px; }
.footer-links { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 20px; }
.footer-links a { font-size: 13px; color: var(--mid); padding: 5px 12px; border-radius: 100px; border: 1px solid var(--border); transition: color .15s, border-color .15s; }
.footer-links a:hover { color: var(--blue); border-color: var(--blue); }
.footer-copy { font-size: 12px; color: var(--mid); border-top: 1px solid var(--border); padding-top: 16px; }

/* ── TABLET / DESKTOP ── */
@media (min-width: 640px) {
  nav { padding: 0 40px; }
  .mmenu { padding: 24px 40px; }
  footer { padding: 48px 40px; }
}
@media (min-width: 900px) {
  nav { padding: 0 52px; }
  .hamburger { display: none; }
  .nav-desktop { display: flex; }
  .nav-cta-btn { display: block; }
  footer { padding: 56px 52px; }
}
"""

def nav(active=""):
    links = [
        ("index.html","Home"),
        ("questions.html","Interview Q&A"),
        ("coach.html","Interview Coach"),
        ("speaking.html","Speaking Guide"),
    ]
    desktop = ""
    for href, label in links:
        cls = ' class="act"' if active == href else ""
        desktop += f'<li><a href="{href}"{cls}>{label}</a></li>\n    '
    
    mobile = ""
    for href, label in links:
        cls = ' class="act"' if active == href else ""
        mobile += f'<a href="{href}"{cls}>{label}</a>\n  '

    return f"""<nav id="nav">
  <a class="nav-logo" href="index.html">GKP<span>.</span></a>
  <ul class="nav-desktop">
    {desktop}
  </ul>
  <a class="nav-cta-btn" href="questions.html">Free Resources</a>
  <button class="hamburger" id="hbg" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mmenu" id="mmenu">
  {mobile}
  <a href="questions.html" class="m-cta">Free Resources →</a>
</div>"""

def footer():
    return """<footer>
  <div class="footer-inner">
    <div class="footer-logo">GKP<span>.</span></div>
    <div class="footer-sub">Gyanesh Kumar Pandey · Capability Leader · Bangalore, India</div>
    <div class="footer-links">
      <a href="index.html">Home</a>
      <a href="questions.html">Interview Q&amp;A</a>
      <a href="coach.html">Interview Coach</a>
      <a href="speaking.html">Speaking Guide</a>
      <a href="swimlane.html">Lifecycle Diagram</a>
      <a href="mailto:mahegyaneshpandey@gmail.com">Email</a>
      <a href="https://www.linkedin.com/in/gyaneshkpandey" target="_blank">LinkedIn ↗</a>
    </div>
    <div class="footer-copy">Free knowledge · No login · No paywall · Shared from 20 years of enterprise experience.</div>
  </div>
</footer>"""

def nav_js():
    return """<script>
const hbg=document.getElementById('hbg'),mm=document.getElementById('mmenu');
hbg.addEventListener('click',()=>{hbg.classList.toggle('open');mm.classList.toggle('open');document.body.style.overflow=mm.classList.contains('open')?'hidden':'';});
mm.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{hbg.classList.remove('open');mm.classList.remove('open');document.body.style.overflow='';}));
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('vis');}),{threshold:.08});
document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
</script>"""

print("Shared components ready")
